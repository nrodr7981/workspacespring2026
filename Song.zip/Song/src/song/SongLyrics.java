package song;

public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("Build it just to watch it fall apart\nLooking for the arrow when you shoot\nYou take yourself seriously, just stop\nListen to your heart\nMirror, mirror, the reflection of the law\nI just wanna show you something new");
	}

}
