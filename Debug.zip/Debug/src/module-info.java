/**
 * 
 */
/**
 * 
 */
module Debug {
	requires java.desktop;
}