package debug;

public class DebugTwo2
{
	public static void main(String[] args)
   {
      int a, b;
      a = 7;
      b = 4;
      System.out.println("The sum is " + (a + b));
      System.out.println("The difference is " + (a - b));
      System.out.println("The product is " + (a * b));
   }
}
