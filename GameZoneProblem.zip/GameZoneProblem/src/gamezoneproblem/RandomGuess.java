package gamezoneproblem;

import java.util.Scanner;
import java.util.Random;

public class RandomGuess {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        System.out.print("Enter anything: ");
        scanner.nextLine();

        int number = random.nextInt(10) + 1;
        System.out.println("Random number: " + number);

        scanner.close();
    }
}
