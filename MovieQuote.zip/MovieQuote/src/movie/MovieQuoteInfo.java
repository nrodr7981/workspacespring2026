package movie;

public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("You take the blue pill\nthe story ends, you wake up in your bed and believe whatever you want to believe.\nYou take the red pill\nyou stay in Wonderland, and I show you how deep the rabbit hole goes.\nThe Matrix\nMorbius\n1999");

	}

}
