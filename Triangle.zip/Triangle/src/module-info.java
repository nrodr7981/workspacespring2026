/**
 * 
 */
/**
 * 
 */
module Triangle {
}